CS676A - Assignment 2
Feb 10, 2016
Shubham Jain, 13683
Vikas Jain, 13788
----------------------------------------
Program file is ip.py
It take 2 command line arguments - name of two image files. Write following command to run the program:

$ python ip.py 'name of file1' 'name of file 2'

e.g.

$ python ip.py 'data/set1/img1.png' 'data/set1/img3.png'

Results images will be stored in the same path as of input files.

Other parameters can be changed, mentioned in the program, by commenting and uncommenting a few lines. 
